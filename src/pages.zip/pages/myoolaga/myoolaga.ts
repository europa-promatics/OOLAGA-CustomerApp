import { Component, ViewChild,ElementRef,HostListener } from '@angular/core';
import { Content,Slides,Slide} from 'ionic-angular';
import { NavController, NavParams,AlertController,MenuController,LoadingController,ModalController } from 'ionic-angular';
import { CreateolagaPage} from '../createolaga/createolaga';
import { InboxPage} from '../myoolaga/inbox/inbox'
import { OfferPage} from '../offer/offer'
import { Http,RequestOptions,Headers } from '@angular/http';
import { OolagaDetailsPage} from '../oolaga-details/oolaga-details';
import { DraftOolagaPage} from '../draft-oolaga/draft-oolaga';
import { Observable} from "rxjs/Rx";
import { ENV} from '../../app/env';
import { AppProvider } from '../../providers/app-provider';
import { OolagaSummaryPage} from '../oolaga-summary/oolaga-summary';
import { AssignedOolagaMapPage } from '../assigned-oolaga-map/assigned-oolaga-map'
import { ChatPage }from '../chat/chat';
import { LaboronlysummaryPage}from '../laboronlysummary/laboronlysummary'
@Component({
  selector: 'page-myoolaga',
  templateUrl: 'myoolaga.html'
})
export class MyoolagaPage {
@ViewChild(Slides) slides: Slides;
@ViewChild(Content) content: Content;
@ViewChild('draft_slide') draft_slide:ElementRef;
@ViewChild('auction_slide') auction_slide:ElementRef;
@ViewChild('active_slide') active_slide:ElementRef;
link1;
data;
data1;
http
oolaga_created:boolean=true;
msg_no:number=0;
enable_service:boolean;
menu
draft_oolaga:boolean=false;
draft_oolaga_enable:boolean=true;
page_selection:boolean=true;
activeSec="active";
assignedOolagas;
assigned_oolaga_enable:boolean=false;
activeSlide:boolean=true;
enableScroll1:boolean=true;
enableScroll2:boolean=true;
enableScroll3:boolean=true;
refreasherEnabled:boolean=false;
  constructor(public modelCtrl:ModalController,private appProvider:AppProvider,public loadingCtrl:LoadingController,public menuCtrl:MenuController,public alertCtrl:AlertController,http:Http,public navCtrl: NavController, public navParams: NavParams) {
    this.http = http;
    this.menu=menuCtrl;
    this.menu.enable(true,"mymenu");
		setInterval(() => {
				  this.updateData();
				}, 5000); 
  }
  refreshOolagas(refresh){
    this.refreasherEnabled=true;
    if(this.activeSec=='draft'){
      this.http.get(ENV.api + '/webservicedraftOolaga/' + localStorage['user_id']).subscribe(data=>{
        if(data.json().response){
          if(data.json().services[0] == null){this.draft_oolaga_enable=true;}
          else if(data.json().services[0] != null){
            this.draft_oolaga_enable=false;
            this.data1=data.json().services;
            this.data1.reverse();
          }
        }else{this.draft_oolaga_enable=true;}
        refresh.complete();
        // this.enableScroll=false;
        this.refreasherEnabled=false;
      },err=>{
       // alert(JSON.stringify('error'+err));
        refresh.complete();
        // this.enableScroll=false;
        this.refreasherEnabled=false;
      })
    }
    else if(this.activeSec=='auction'){
      this.http.post(ENV.api + '/webserviceuserOolagas',{user_id:localStorage['user_id']}).subscribe(data=>{
        if(data.json().response){
          if(data.json().oolagas[0] == null){this.oolaga_created=true;}
          else if(data.json().oolagas[0] != null){
            this.oolaga_created=false;
            this.data=data.json().oolagas;
            this.data.reverse();
          }
        }else{this.oolaga_created=true;}
        refresh.complete();
        // this.enableScroll=false;
        this.refreasherEnabled=false;
      },err=>{
       // alert(JSON.stringify('error'+err));
        refresh.complete();
        // this.enableScroll=false;
        this.refreasherEnabled=false;
      })
    }
    else if(this.activeSec=='active'){
      this.http.post(ENV.api +'/webserviceshowuseroolaga',{user_id:localStorage['user_id']}).subscribe(data=>{
        if(data.json().response){
          this.assignedOolagas=data.json().data.reverse()
          if(data.json().data[0] != null){this.assigned_oolaga_enable=true;}
          else{this.assigned_oolaga_enable=false;}
        }
        else{this.assigned_oolaga_enable=false;}
        refresh.complete();
        // this.enableScroll=false;
        this.refreasherEnabled=false;
      },err=>{
       // alert(JSON.stringify('error'+err));
        refresh.complete();
        // this.enableScroll=false;
        this.refreasherEnabled=false;
      })
    }
  }
  slideChanged() {
    let currentIndex = this.slides.getActiveIndex();
    if (currentIndex == 0) {
      this.activeSec = 'draft'
    }
    else if (currentIndex == 1) {
      this.activeSec = 'auction'
    }
    else {
      this.activeSec = 'active'
    }
  }
  updateData(){
	  // this.refreasherEnabled=true;
    if(this.activeSec=='draft'){
      this.http.get(ENV.api + '/webservicedraftOolaga/' + localStorage['user_id']).subscribe(data=>{
        if(data.json().response){
          if(data.json().services[0] == null){this.draft_oolaga_enable=true;}
          else if(data.json().services[0] != null){
            this.draft_oolaga_enable=false;
            this.data1=data.json().services;
            this.data1.reverse();
          }
        }else{this.draft_oolaga_enable=true;}
       // refresh.complete();
        // this.enableScroll=false;
        //this.refreasherEnabled=false;
      },err=>{
        //alert(JSON.stringify('error'+err));
        //refresh.complete();
        // this.enableScroll=false;
        //this.refreasherEnabled=false;
      })
    }
    else if(this.activeSec=='auction'){
      this.http.post(ENV.api + '/webserviceuserOolagas',{user_id:localStorage['user_id']}).subscribe(data=>{
        if(data.json().response){
          if(data.json().oolagas[0] == null){this.oolaga_created=true;}
          else if(data.json().oolagas[0] != null){
            this.oolaga_created=false;
            this.data=data.json().oolagas;
            this.data.reverse();
          }
        }else{this.oolaga_created=true;}
        //refresh.complete();
        // this.enableScroll=false;
      //  this.refreasherEnabled=false;
      },err=>{
        //alert(JSON.stringify('error'+err));
       // refresh.complete();
        // this.enableScroll=false;
        //this.refreasherEnabled=false;
      })
    }
    else if(this.activeSec=='active'){
      this.http.post(ENV.api +'/webserviceshowuseroolaga',{user_id:localStorage['user_id']}).subscribe(data=>{
        if(data.json().response){
          this.assignedOolagas=data.json().data.reverse()
          if(data.json().data[0] != null){this.assigned_oolaga_enable=true;}
          else{this.assigned_oolaga_enable=false;}
        }
        else{this.assigned_oolaga_enable=false;}
        //refresh.complete();
        // this.enableScroll=false;
       // this.refreasherEnabled=false;
      },err=>{
        //alert(JSON.stringify('error'+err));
        //refresh.complete();
        // this.enableScroll=false;
       // this.refreasherEnabled=false;
      })
    }
	  
  }
  tabChange() {
    let len: number = this.slides.length()
    let currentIndex = this.slides.getActiveIndex();
    if (len > 0) {
      if (this.activeSec == 'draft') {
        if (currentIndex != 0) {
          this.slides.slideTo(0)

        }
      }
      else if (this.activeSec == 'auction') {
        if (currentIndex != 1) {
          this.slides.slideTo(1)

        }
      }
      else if (this.activeSec == 'active') {
        if (currentIndex != 2) {
          this.slides.slideTo(2)
        }
      }
    }
  }
  
  titleCase(str){
if(str){
    return str.replace(
        /\w\S*/g,
        function(txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        }
    );
}else{
	return "";
}

}
  openChat(value,image,name, oolagaid){
    console.log(value)
    this.navCtrl.push(ChatPage,{receiver_id:value,image:image,name:name, oolaga:oolagaid})
    // let chat = this.modelCtrl.create(ChatPage,{receiver_id:value,image:image,name:name});
    // chat.dismiss(data=>{
    // })
    // chat.present();
  }
  oolaga_detail(value){
    if(value.service=='Labor Only'){
      if(this.page_selection){
        this.navCtrl.push(LaboronlysummaryPage,{data:value})
      }
      this.page_selection=true;
    }
    else{
      if(this.page_selection){
        this.navCtrl.push(OolagaSummaryPage,{data:value,page:'auction'})
      }
      this.page_selection=true;
    }
  }
  active_oolaga_detail(value){
    if(value.cancel_status!='cancel_by_helper'){
        console.log(value)
        this.navCtrl.push(OolagaSummaryPage,{data:value,page:'active'})
    }
    else{
      let alert= this.alertCtrl.create({
        title:'Do you want to delete',
        buttons:[{
          text:'NO',
          handler:()=>{
          }
        },{
          text:'YES',
          handler:()=>{
            let loading=this.loadingCtrl.create()
             loading.present();
             this.http.get(ENV.api + '/webservicedeletecanceledoolaga/'+value.oolaga_id)
             .subscribe(data=>{
               if(data.json().response){
                 this.ionViewWillEnter();
               }
               loading.dismiss();
             },err=>{
               loading.dismiss();
             })
          }
        }]
      })
      alert.present();
    }
  }
  deleteCancelOolaga(){

  }
  openmap(value){
    if(value.service_id==7){

    }
    else if(value.service_id!=7){
      console.log('map')
      this.navCtrl.push(AssignedOolagaMapPage,{data:value})
    }
  }
  deleteDraft(value){
    // this.http.get(ENV.api + '/webservicedeleteDraft/'+value.id)
    console.log('DeleteEnable');
    let confirm=this.alertCtrl.create({
          title:'Do you want to delete',
          buttons:[ 
                    { 
                     text:'Yes',
                     handler:()=>
                     {
                       let loading=this.loadingCtrl.create()
                       loading.present();
                       this.http.get(ENV.api + '/webservicedeleteDraft/'+value.id)
                       .subscribe(data=>{
                         if(JSON.parse(data['_body']).response)
                         {  
                            this.http.get(ENV.api + '/webservicedraftOolaga/' + localStorage['user_id'])
                            .subscribe(data=>{
                              let d =JSON.parse(data['_body']);
                              if(d.response){
                                if(d.services[0] == null)
                                {
                                  this.draft_oolaga_enable=true;
                                }
                                else if(d.services[0] != null){
                                  this.draft_oolaga_enable=false;
                                  this.data1=d.services;
                                  this.data1.reverse();
                                }
                              }
                              else{
                                  this.draft_oolaga_enable=true;
                              }
                              loading.dismiss();
                              let alert = this.alertCtrl.create({
                                  title:'Draft Deleted',
                                  buttons:[{
                                    text:'Ok'
                                  }]
                                })
                              alert.present();
                            })
                         }
                         else{
                            loading.dismiss();
                            let alert = this.alertCtrl.create({
                              title:'Oops...',
                              message:'Something Wrong...',
                              buttons:[{
                                text:'Ok'
                              }]
                            })
                            alert.present();
                         }
                       })
                     },
                    },
                    {
                     text:'No',
                     handler:()=>
                     {

                     },
                   }]
                  });
      confirm.present();
  }
  showDraft(value){
    console.log(value);
    localStorage['draftOolaga']=JSON.stringify(value);
      this.navCtrl.push(DraftOolagaPage);
  }
  
  createoolaga(){
    if(!this.draft_oolaga_enable){
      let confirm=this.alertCtrl.create({
          message:'We noticed you have an ooLAGA draft saved.Would you like to edit your draft or create a new ooLAGA',
          buttons:[{ text:'NEW ooLAGA',
                     handler:()=>
                        {
                          this.appProvider.createNew();
                          this.navCtrl.push(CreateolagaPage,{data:'new'});
                        },
                    },
                    {
                     text:'EDIT',
                     handler:()=>{
                          this.navCtrl.push(CreateolagaPage,{data:'new'});
                         // this.navCtrl.push(DraftOolagaPage,{data:'new'});
                       },
                   }]
                  });
      confirm.present();
    }
    else{
      this.appProvider.createNew();
      this.navCtrl.push(CreateolagaPage,{data:'new'});
    }
  }
  notificationpage(id,offer){
    if(offer!=0 || offer!='0'){
      this.navCtrl.push(OfferPage,{id:id});
    }
    else{
      let alert=this.alertCtrl.create({
        title:'Alert',
        message:'No Offers',
        buttons:['Ok']
      })
      alert.present();
    }
  }
  messagespage(){
    this.msg_no=0;
    localStorage['msg_no']=0;
    this.navCtrl.push(InboxPage);
  }
  ionViewDidEnter(){
    if(this.activeSlide)
    {
      this.slides.slideTo(2);this.activeSlide=false;
    }
  }
  @HostListener('scroll', ['$event'])
  onScroll(event) {
    if(this.activeSec=="draft"){
      if(document.getElementById('draft_slide').scrollTop==0){this.enableScroll1=true;}
      else{this.refreasherEnabled?'':this.enableScroll1=false}
    }
    if(this.activeSec=="auction"){
      if(document.getElementById('auction_slide').scrollTop==0){this.enableScroll2=true;}
      else{this.refreasherEnabled?'':this.enableScroll2=false}
    }
    if(this.activeSec=="active"){
      if(document.getElementById('active_slide').scrollTop==0){this.enableScroll3=true;}
      else{this.refreasherEnabled?'':this.enableScroll3=false}
    }
  }
  ionViewWillEnter() {
    this.enable_service=true;
    localStorage['chat']=0;
    localStorage['draft_oolaga']=true;
    // this.http.post(this.link + '',{user_id:localStorage['user_id']})
    // .subscribe(data=>{
    //   console.log(JSON.parse(data._body).response);
    //   localStorage['draft_oolaga']=true;
    //   localStorage['draft_oolaga']=false;
    // })
    let loading = this.loadingCtrl.create()
    loading.present();
    Observable.forkJoin(
      this.http.post(ENV.api + '/webserviceuserOolagas',{user_id:localStorage['user_id']}),
      this.http.get(ENV.api + '/webservicedraftOolaga/' + localStorage['user_id']),
      this.http.post(ENV.api +'/webserviceshowuseroolaga',{user_id:localStorage['user_id']})
      )
    .subscribe(data => {
      let data1= JSON.parse(data[0]['_body']);
      let data2= JSON.parse(data[1]['_body']);
      let data3= JSON.parse(data[2]['_body']);
      console.log('active',data1);
      console.log('draft',data2);
      console.log('assignedOolagas',data3);
      if(data3.response){
      this.assignedOolagas=data3.data.reverse()
        if(data3.data[0] != null){
          this.assigned_oolaga_enable=true;
          console.log(1)
        }
        else{
          this.assigned_oolaga_enable=false;
          console.log(2)
        }
      }else{
        this.assigned_oolaga_enable=false;
          console.log(3)
      }
      if(data1.response){
        if(data1.oolagas[0] == null)
        {
          this.oolaga_created=true;
        }
        else if(data1.oolagas[0] != null){
          this.oolaga_created=false;
          this.data=data1.oolagas;
          this.data.reverse();
        }
      }
      else{
          this.oolaga_created=true;
      }

      if(data2.response){
        if(data2.services[0] == null)
        {
          this.draft_oolaga_enable=true;
        }
        else if(data2.services[0] != null){
          this.draft_oolaga_enable=false;
          this.data1=data2.services;
          this.data1.reverse();
        }
      }
      else{
          this.draft_oolaga_enable=true;
      }
        loading.dismiss();
        this.content.scrollToTop();
      },err => {
        loading.dismiss();
       // alert(JSON.stringify('error'+err));
      });
    this.update_msg();
  }
  ionViewWillLeave() {
    this.enable_service=false;
  }
  update_msg(){
    if(this.enable_service==true){
      setTimeout(()=>{
        this.msg_no++
        this.update_msg()
      },5000)
    }
  }
  get_detail(value){
    this.navCtrl.push(OolagaDetailsPage,{data:value})
  }
}

