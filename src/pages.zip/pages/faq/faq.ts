import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http'
import {ENV} from '../../app/env'

/*
  Generated class for the FAQ page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-faq',
  templateUrl: 'faq.html'
})
export class FAQPage {
	qus;
  value;
  link=ENV.api+"/webservicefaqs";
  http;
  constructor(http:Http,public navCtrl: NavController, public navParams: NavParams) {
  	this.qus=[];
    this.http=http;
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad FAQPage');
    this.qus=[
          {
          question:'What is Oolaga?',
          answer:'Oolaga connects people who need something moved with people willing to move it. The price is determined by you and the helper through a bidding process. Oolaga can be used for small moves, but also for a variety of other scenarios like getting furniture delivered from a store, donating to charity, getting “muscle” help only or however else you see fit.'
          },
          {
          question:'How do I pay my helper?',
          answer:'Once you have selected a helper and agreed on the price, Oolaga will charge your credit card and hold on to the funds until the transaction is completed.  You will also have the opportunity to tip the helper before the transaction is complete.'
          },
          {
          question:'How safe is using Oolaga?',
          answer:'All Oolaga helpers have undergone a full background check and completed training to provide the highest possible level of service.  In addition, our review system will ensure full transparency into their track record in helping others.'
          },
          {
          question:'Are my goods insured?',
          answer:'Yes, Oolaga does provide insurance on your goods being moved when using our app.  Please see our terms and agreements or contact us for more details.'
          },
          {
          question:'What if I must cancel an Oolaga?',
          answer:'We understand, things happen.  See our cancellation policy for more detail.'
          },
          {
          question:'What if my helper cancels?',
          answer:'This may happen however our helpers adhere to a policy that includes monetary penalties to discourage “last minute” cancelations.'
          },
          {
          question:'How do I resolve a conflict?',
          answer:'Contact us and we will support you through the process'
          }]
    this.http.get(this.link).subscribe(data=>{
      if(JSON.parse(data._body).response=true){
        console.log(JSON.parse(data._body))
      }
    })
  }
  enable(value){
    this.value=value;
  }

}
